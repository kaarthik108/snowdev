import sys


def main():
    print('Did you mean pyjoke?')
    return 1

if __name__ == '__main__':
    sys.exit(main())
